from flask import Flask, render_template, request
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField
from wtforms.validators import DataRequired
from data import db_session, users
from werkzeug.security import generate_password_hash


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
db_session.global_init("db/blogs.sqlite")
session = db_session.create_session()


class RegisterForm(FlaskForm):
    email = StringField('Login / email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    repeat_password = PasswordField('Repeat password', validators=[DataRequired()])
    surname = StringField('Surname', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    age = IntegerField('Age', validators=[DataRequired()])
    position = StringField('Position', validators=[DataRequired()])
    speciality = StringField('Speciality', validators=[DataRequired()])
    address = StringField('Address', validators=[DataRequired()])
    submit = SubmitField('Войти')


@app.route('/register', methods=['GET', 'POST'])
def index():
    global session
    form = RegisterForm()
    if form.validate_on_submit():
        if request.form['password'] != request.form['repeat_password']:
            return render_template('register.html', title='Регистрация', form=form, passwords_do_not_match=True)
        try:
            user = users.User()
            user.email = request.form['email']
            user.hashed_password = generate_password_hash(request.form['password'])
            user.surname = request.form['surname']
            user.name = request.form['name']
            user.address = request.form['address']
            user.speciality = request.form['speciality']
            user.position = request.form['position']
            user.age = request.form['age']
            session.add(user)
            session.commit()
            return "Успешно добавлено"
        except BaseException:
            return "Произошла ошибка при добавлении в базу. Попробуйте снова."
    return render_template('register.html', title='Регистрация', form=form)


if __name__ == '__main__':
    app.run(port=5000, host='localhost', debug=True)
